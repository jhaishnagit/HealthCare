import React, { useState, useContext } from "react";
import MedicalSidebar from "./MedicalSidebar";
import MedicalHeader from "./MedicalHeader";
import "./css/MedicalDashboard.css";

import PatientPrescription from "./jsx_files/PatientPrescription";
import MedicalStock from "./jsx_files/MedicalStock";
import Customers from "./jsx_files/Customers";
import Inventory from "./jsx_files/Inventory";
import Billing from "./jsx_files/Billing";
import Orders from "./jsx_files/Orders";
import SearchPage from "./jsx_files/MedicinePage";

import { UserContext } from "../../context/UserContext";

// 📊 recharts
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  BarChart,
  Bar,
} from "recharts";

const MedicalDashboard = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [page, setPage] = useState("dashboard");

  const { user } = useContext(UserContext);

  return (
    <div className="med-wrapper">

      {/* HEADER */}
      <MedicalHeader toggleSidebar={() => setSidebarOpen(!sidebarOpen)} user={user} />

      {/* SIDEBAR */}
      <MedicalSidebar
        sidebarOpen={sidebarOpen}
        setSidebarOpen={setSidebarOpen}
        setPage={setPage}
      />

      {/* MAIN CONTENT */}
      <div
        className="med-main"
        style={{
          marginLeft: sidebarOpen ? "250px" : "0",
        }}
      >

        {/* DASHBOARD PAGE */}
        {page === "dashboard" && (
          <div className="dashboard-container">

            {/* SUMMARY CARDS */}
            <div className="cards-row">
              <div className="dash-card primary"><h3>Total Medicines</h3><p>120</p></div>
              <div className="dash-card info"><h3>Low Stock</h3><p>15</p></div>
              <div className="dash-card warning"><h3>Out of Stock</h3><p>10</p></div>
              <div className="dash-card danger"><h3>Expired</h3><p>5</p></div>
              <div className="dash-card purple"><h3>Expiring Soon</h3><p>8</p></div>
            </div>

            <div className="cards-row">
              <div className="dash-card success"><h3>New Orders</h3><p>12</p></div>
              <div className="dash-card warning"><h3>Pending Orders</h3><p>7</p></div>
              <div className="dash-card primary"><h3>Completed Orders</h3><p>30</p></div>
              <div className="dash-card info"><h3>Total Customers</h3><p>85</p></div>
              <div className="dash-card success"><h3>Total Payments</h3><p>₹1,50,000</p></div>
              <div className="dash-card danger"><h3>Pending Payments</h3><p>₹22,000</p></div>
            </div>

            {/* GRAPH ROW */}
            <div className="graph-row">

              {/* MONTHLY SALES */}
              <div className="graph-card">
                <h3>Monthly Sales</h3>
                <ResponsiveContainer width="100%" height={260}>
                  <LineChart
                    data={[
                      { month: "Jan", sales: 25000 },
                      { month: "Feb", sales: 30000 },
                      { month: "Mar", sales: 28000 },
                      { month: "Apr", sales: 35000 },
                      { month: "May", sales: 32000 },
                      { month: "Jun", sales: 40000 },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="sales" stroke="#1f3c88" strokeWidth={3} />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* ORDERS BAR GRAPH */}
              <div className="graph-card">
                <h3>Orders Overview</h3>
                <ResponsiveContainer width="100%" height={260}>
                  <BarChart
                    data={[
                      { name: "New", value: 12 },
                      { name: "Pending", value: 7 },
                      { name: "Completed", value: 30 },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="value" fill="#4caf50" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* LOW STOCK TABLE */}
            <h3 className="section-subtitle">Low Stock Medicines</h3>
            <table className="styled-table">
              <thead>
                <tr><th>Medicine</th><th>Qty</th><th>Reorder</th><th>Rack</th></tr>
              </thead>
              <tbody>
                <tr><td>Paracetamol</td><td>6</td><td>10</td><td>R1-A2</td></tr>
                <tr><td>Vitamin D</td><td>5</td><td>10</td><td>R3-C1</td></tr>
              </tbody>
            </table>

            {/* OUT OF STOCK */}
            <h3 className="section-subtitle">Out of Stock</h3>
            <table className="styled-table">
              <thead>
                <tr><th>Medicine</th><th>Category</th><th>Rack</th></tr>
              </thead>
              <tbody>
                <tr><td>Cetirizine</td><td>Anti Allergy</td><td>R2-B3</td></tr>
              </tbody>
            </table>

            {/* EXPIRING SOON */}
            <h3 className="section-subtitle">Expiring Soon</h3>
            <table className="styled-table">
              <thead>
                <tr><th>Medicine</th><th>Batch</th><th>Expiry</th><th>Qty</th></tr>
              </thead>
              <tbody>
                <tr><td>Amoxicillin</td><td>AMX-234</td><td>04/01/2025</td><td>20</td></tr>
              </tbody>
            </table>

          </div>
        )}

        {/* OTHER PAGES */}
        {page === "patient" && <PatientPrescription />}
        {page === "store" && <MedicalStock />}
        {page === "billing" && <Billing />}
        {page === "inventory" && <Inventory />}
        {page === "customers" && <Customers />}
        {page === "orders" && <Orders />}
        {page === "search" && <SearchPage />}

      </div>
    </div>
  );
};

export default MedicalDashboard;
