// src/components/MedicalDashboard/MedicalHeader.jsx
import React, { useContext } from "react";
import "./css/MedicalHeader.css";
import { FiMenu, FiBell } from "react-icons/fi";
import { UserContext } from "../../context/UserContext";

const MedicalHeader = ({ toggleSidebar }) => {
  const { user } = useContext(UserContext);

  // THIS IS THE MAGIC — Forces real photo to show correctly
  const getRealPhoto = () => {
    if (!user?.image) {
      // Fallback: Beautiful initial avatar (only if no photo)
      return `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || "User")}&background=1e40af&color=fff&size=128&bold=true`;
    }

    // If it's already a full URL (http or data:)
    if (user.image.startsWith("http") || user.image.startsWith("data:")) {
      return user.image;
    }

    // THIS IS YOUR CASE — base64 string from backend
    return `data:image/jpeg;base64,${user.image}`;
  };

  return (
    <header className="med-header">
      <div className="header-left">
        <button className="menu-btn" onClick={toggleSidebar}>
          <FiMenu size={30} />
        </button>
        <h1 className="header-title">Medical Dashboard</h1>
      </div>

      <div className="header-right">
        <button className="bell-btn">
          <FiBell size={26} />
        </button>

        <div className="user-profile">
          <img
            src={getRealPhoto()}
            alt="Your Photo"
            className="user-avatar"
            onError={(e) => {
              // Final fallback if anything goes wrong
              e.target.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(user?.name || "U")}&background=6366f1&color=fff&size=128`;
            }}
          />
          <span className="user-name">{user?.name || "Medical User"}</span>
        </div>
      </div>
    </header>
  );
};

export default MedicalHeader;